#!/bin/bash
# create multiresolution windows icon
ICON_DST=../../src/qt/res/icons/tokcoin.ico

convert ../../src/qt/res/icons/tokcoin-16.png ../../src/qt/res/icons/tokcoin-32.png ../../src/qt/res/icons/tokcoin-48.png ${ICON_DST}
